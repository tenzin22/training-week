# 参加者ガイド: Kiro IDE で開発中のドキュメントを整備する

## ゴール

コードを正としながら、必要なファイルだけを Kiro に渡し、ドキュメントの不整合を修正します。その判断基準を Steering に残し、Agent Hooks で検証を再現可能にします。

## タイムテーブル

| 時刻 | 内容 | 時間 |
|---|---|---:|
| 0:00-0:25 | 講義 | 25分 |
| 0:25-0:30 | Starter Project | 5分 |
| 0:30-0:50 | Context | 20分 |
| 0:50-1:15 | Steering | 25分 |
| 1:15-1:35 | Agent Hooks | 20分 |
| 1:35-1:45 | 休憩 | 10分 |
| 1:45-2:10 | draw.io | 25分 |
| 2:10-2:15 | Checkpoints | 5分 |
| 2:15-2:30 | Q&A | 15分 |

# 1. 講義（25分）

講師の説明を聞きながら、次の区別を確認してください。

- Context: 今回の依頼で Kiro に見せる具体的なファイルや選択範囲
- Steering: 複数の依頼で再利用するルール。適用範囲を明示する
- Agent Hooks: 決めたタイミングで同じ確認を開始する仕組み
- Checkpoint: 変更前後を比較し、不要な変更だけを戻す安全網

重要な原則は「広く読ませる前に、根拠となるコードと更新対象の文書を指定する」です。

# 2. Starter Project（5分）

ターミナルで `starter-project` に移動し、次を実行します。

```bash
python3 --version
python3 -m unittest discover -s tests -v
python3 scripts/validate_docs.py
```

期待される観察結果:

- Python は 3.12 系である
- 4件のテストが成功する
- 検証は3件の不整合を表示し、終了コード1になる
- 不整合はテスト失敗ではなく、コードと文書のずれである

任意で現在のデータを確認します。

```bash
PYTHONPATH=src python3 -m document_registry.cli --data data/documents.json list
```

## 2.1 ハンズオン用の画面配置

1. Kiro のチャットタブを右クリックします。
2. **Open in Editor** を選び、Dockable Chat をエディター領域へ開きます。
3. `docs/`、`src/document_registry/`、Git Diff と並べて確認できる配置にします。

Dockable Chat が利用できない場合は通常のチャットパネルのまま進めます。これは演習の必須条件ではありません。

# 3. Context: 必要な根拠だけを渡す（20分）

## 3.1 要件と実装を比較する

Kiro Chat で `docs/requirements.md` と `src/document_registry/registry.py` を IDE のコンテキストとして追加します。

対象コードを選択して **Ask Kiro** へ渡します。`registry.py` の `ALLOWED_CATEGORIES` を選択し、macOS は `Cmd+L`、Windows/Linux は `Ctrl+L` で現在のチャットへ追加してください。新しいチャットで比較したい場合は `Cmd+Shift+L` または `Ctrl+Shift+L` を使います。

選択範囲と `docs/requirements.md` の2つだけを根拠として、次を送信します。

**プロンプト 1**

```text
#docs/requirements.md と #src/document_registry/registry.py だけを根拠として、許可されている category の不一致を表で示してください。まだファイルは変更しないでください。コードを現行仕様として扱い、推測は「要確認」と明記してください。
```

期待される観察結果:

- `plan` は文書にだけ存在する
- `decision` はコードにだけ存在する
- 指定していないファイルの内容を根拠にしない
- 変更前に差分候補を確認できる

## 3.2 アーキテクチャと実装を比較する

`docs/architecture.md`、`src/document_registry/registry.py`、`data/documents.json` をコンテキストに追加します。

**プロンプト 2**

```text
#docs/architecture.md、#src/document_registry/registry.py、#data/documents.json を比較し、永続化形式について「文書の主張」「実装の事実」「必要な修正」を3項目で答えてください。変更はしないでください。
```

期待される観察結果:

- 文書は CSV と記載している
- 実装とサンプルデータは JSON を使用している
- 修正対象はアーキテクチャ文書であり、コード変更は不要である

## 3.3 対象文書だけを更新する

3つの文書と `scripts/validate_docs.py` をコンテキストに追加します。

**プロンプト 3**

```text
#docs/requirements.md、#docs/architecture.md、#docs/operations.md、#scripts/validate_docs.py を使い、検証条件を満たす最小差分を提案してください。実装コードとデータは変更しないでください。修正後に python3 scripts/validate_docs.py を実行し、結果を報告してください。
```

提案差分を確認してから Apply します。期待される更新:

- 要件の category が `design`、`runbook`、`decision` になる
- アーキテクチャが JSON 永続化を説明する
- 運用手順に `python3 -m unittest discover -s tests -v` が載る
- 検証が `Documentation validation passed.` で終了する

# 4. Steering: 適用範囲を設計する（25分）

`.kiro/steering/` に次の3ファイルを作ります。フロントマターを含めて保存してください。

## 4.1 always: プロジェクト全体の不変条件

`.kiro/steering/project-standards.md`

```markdown
---
inclusion: always
---

# Project standards

- Source code is the current behavioral source of truth.
- Use synthetic examples only. Never add customer names, accounts, or confidential identifiers.
- Do not change runtime behavior when the task is documentation maintenance.
- Run unit tests and the documentation validator before reporting completion.
```

## 4.2 fileMatch: Markdown 編集時だけ適用

`.kiro/steering/docs-style.md`

```markdown
---
inclusion: fileMatch
fileMatchPattern: "docs/**/*.md"
---

# Documentation style

- Write concrete statements that can be checked against source code.
- Include exact commands and expected outcomes.
- Keep requirements, architecture, and operations concerns in their respective files.
- Prefer minimal edits over broad rewrites.
```

## 4.3 manual: 必要なときだけ明示的に参照

`.kiro/steering/release-doc-review.md`

```markdown
---
inclusion: manual
---

# Release documentation check

- Compare changed constants and CLI commands with all files under docs/.
- Record user-visible documentation changes in CHANGELOG.md.
- Report unresolved mismatches instead of guessing.
```

保存後、次を送信します。

**プロンプト 4**

```text
現在有効な Steering を、always・fileMatch・manual の区分で説明してください。#release-doc-review はまだ手動参照しないでください。docs/operations.md を1行だけ改善する場合に適用されるルールを列挙してください。
```

期待される観察結果:

- `project-standards.md` は常時適用される
- `docs-style.md` は `docs/**/*.md` に一致する編集で適用される
- `release-doc-review.md` は自動適用されない

次に manual Steering を明示します。

**プロンプト 5**

```text
#release-doc-review を適用して、今回のドキュメント修正がリリース可能か確認してください。ファイルは変更せず、テスト、文書検証、CHANGELOG の3項目を Pass/Fail で報告してください。
```

期待される観察結果:

- manual ルールが今回だけ参照される
- CHANGELOG が未更新なら Fail または要対応として見つかる
- 根拠のない「完了」判定をしない

最後に `CHANGELOG.md` の `Unreleased` に、文書整合性修正を1行追加します。

# 5. Agent Hooks: 検証を繰り返せる形にする（20分）

Hook 設定は `.kiro/hooks/*.json` に保存されます。本演習では、Kiro が Markdown を編集した後に決定的な validator を実行する `PostFileSave` Hook を1つ作ります。

> `PostFileSave` は **Kiro Agent が保存・編集したファイル**に反応します。人がエディターで手動保存しただけでは発火しません。

## 5.1 文書保存後の検証 Hook

Agent Hooks の `+` から「Ask Kiro to create a hook」を選び、次を入力します。

```text
Kiro Agent が docs 配下の Markdown ファイルを保存または編集した後に、プロジェクトルートで python3 scripts/validate_docs.py を実行する Hook を作ってください。PostFileSave を使い、matcher は ^docs/.*\.md$、action は command にしてください。文書の自動修正、commit、外部送信は行わないでください。
```

生成された `.kiro/hooks/*.json` で次を確認します。

- `version` は `v1`
- `trigger` は `PostFileSave`
- `matcher` は `^docs/.*\.md$`
- command は `python3 scripts/validate_docs.py`

### 発火・非発火・失敗を確認する

1. Kiro に `docs/architecture.md` へ「このアプリはネットワークへ接続しない」という正しい説明を1行追加させる。Hook が発火し、validator が成功することを確認する。
2. 人が `README.md` を手動保存する。Hook が発火しないことを確認する。
3. Kiro に `docs/architecture.md` の `JSON` を一時的に `CSV` へ変更させる。Hook が発火し、validator が失敗することを確認する。
4. Kiro にその1行だけ元へ戻させ、validator が再び成功することを確認する。

期待される観察結果:

- 発火条件は決定的だが、修正案の内容は Agent の提案である
- 最終合否は会話上の自己評価ではなく validator の終了コードで決まる
- 対象外のファイルや手動保存では発火しない

## 5.2 manual Steering で同期レビューする

オンデマンドのレビューは、前の章で作った `release-doc-review.md` を明示的に参照して実行します。

```text
#release-doc-review を適用してください。src/document_registry/registry.py と src/document_registry/cli.py を現行仕様として docs/requirements.md、docs/architecture.md、docs/operations.md を確認してください。ファイルは変更せず、テスト、文書検証、CHANGELOG、Git Diff を Pass / Fail で報告してください。
```

期待される観察結果:

- manual Steering はこの依頼だけに適用される
- Hook と manual Steering の役割を区別できる
- 文書変更を自動承認せず、最終合否をテストと validator で判断する

# 6. 休憩（10分）

変更を保存し、テストとバリデータが成功する状態で休憩します。

# 7. draw.io（25分）

この演習は同じフォルダーの `drawio-lab-ja.md` に従ってください。Project Document Registry の読み込み、検証、検索、文書更新の流れを図にします。

このガイドでは draw.io ファイルの具体的な作成手順を重複させません。演習後は次を確認してください。

- 図のノード名がコード中の構成要素と対応する
- JSON ストレージが CSV として残っていない
- 図だけで保証できない運用コマンドは `docs/operations.md` に残す

# 8. Checkpoints: 短い復元演習（5分）

1. Kiro の Checkpoint 一覧で、文書修正前の時点を選びます。
2. 差分プレビューで `docs/operations.md` の変更を確認します。
3. そのファイルだけを一度復元します。
4. `python3 scripts/validate_docs.py` が失敗することを確認します。
5. 直後の Checkpoint へ戻し、再度バリデータが成功することを確認します。

期待される観察結果:

- 復元前に対象差分を確認できる
- プロジェクト全体を無条件に巻き戻さず、対象を限定できる
- Checkpoint 復元後もテストとバリデータで状態を確認する必要がある

# 9. Q&A（15分）

質問の観点例:

- Context に含めるファイルをどう絞るか
- always と fileMatch の境界をどう決めるか
- manual Steering をレビュー手順にどう組み込むか
- Hook に自動修正を許可する範囲
- 図、コード、文章のどれを正とするか

## 9.1 Chatを振り返り用にエクスポートする

1. 使用したチャットタブを右クリックします。
2. **Export Chat** を選択します。
3. ZIP に `session.json`、`messages.jsonl`、サブ実行がある場合は `sub-executions/*.jsonl` が含まれることを確認します。
4. 共有前に、コード、会話、パス、機密情報が含まれていないか必ずレビューします。

本演習では合成データだけを使用します。実案件のチャットをそのまま外部共有してはいけません。Export Chat は成果物そのものではなく、どの Context、判断、検証を使ったかを振り返るための記録として扱います。

## 最終確認

```bash
python3 -m unittest discover -s tests -v
python3 scripts/validate_docs.py
PYTHONPATH=src python3 -m document_registry.cli --data data/documents.json list --category decision
```

すべて成功し、架空の `ADR-014` が表示されれば完了です。
