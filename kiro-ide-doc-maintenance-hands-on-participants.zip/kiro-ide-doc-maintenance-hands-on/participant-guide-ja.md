# 参加者ガイド: 開発中のコードに合わせてドキュメントを整備する

## ゴール

`app.py` を現行仕様として、必要な Context だけでドキュメントのずれを直し、Steering と Hook で再発を防ぎます。

## タイムテーブル

| 内容 | 時間 |
|---|---:|
| 講義 | 25分 |
| Starter Project | 5分 |
| Context deep dive | 35分 |
| Steering | 20分 |
| Agent Hooks | 15分 |
| 休憩 | 10分 |
| draw.io | 20分 |
| Checkpoints | 5分 |
| Q&A・振り返り | 15分 |

各章で「予測する -> 実行する -> 結果を見る -> 次回も効く仕組みにする」を繰り返します。

# 1. Starter Project

Kiro IDE で `starter-project` を開きます。

### Windows PowerShell

```powershell
py -3.12 --version
py -3.12 -m unittest discover -s tests -v
py -3.12 scripts/validate_docs.py
py -3.12 app.py
```

### macOS / Linux

```bash
python3 --version
python3 -m unittest discover -s tests -v
python3 scripts/validate_docs.py
python3 app.py
```

開始状態ではテスト3件が成功し、validator は次の3件を報告します。

```text
コード: status は open / closed    ドキュメント: open / paused
コード: JSON                       ドキュメント: CSV
コード: --status                   ドキュメント: --state
```

この時点ではファイルを変更しません。

## Git baseline

Checkpoint 自体は Git 不要ですが、`#Git Diff` のため参加者本人が初期 commit を作ります。

```bash
git init -b main
git config user.name "Kiro Workshop Participant"
git config user.email "kiro-workshop@example.invalid"
git add .
git commit -m "chore: establish workshop baseline"
git status --short
```

`git status --short` に何も表示されれば合格です。

## 1.1 画面配置

1. Kiro のチャットタブを右クリックします。
2. **Open in Editor** を選び、Dockable Chat をコードやドキュメントの横へ配置します。
3. 利用できない場合は通常のチャットパネルのまま続けます。

# 2. Context: AI に渡す情報を最適化する（35分）

この章の目的は、Context 機能を全部使うことではありません。**問いに対して、最小で十分な evidence source を選ぶこと**です。

## 2.1 Context 選択クイズ: 先に選ぶ（5分）

Kiro を操作する前に、各場面で最初に使う Context を選びます。

| 場面 | 自分の選択 | 推奨 |
|---|---|---|
| status を定義する場所が分からない |  | `#Codebase` |
| `app.py` の `ALLOWED_STATUSES` を確認したい |  | Ask Kiro の選択範囲 / `#File` |
| `docs/` 全体の記載を横断して確認したい |  | `#Folder` |
| IDE が検出した syntax・type・import error を調べたい |  | `#Problems` |
| tests / validator の実行結果を根拠にしたい |  | `#Terminal` |
| 適用後に何が変わったか確認したい |  | `#Git Diff` |

判断軸:

```text
場所が不明      -> #Codebase で discovery
場所が既知      -> 選択範囲 / #File で precise evidence
範囲が既知      -> #Folder で bounded breadth
静的な問題      -> #Problems
実行時の事実    -> #Terminal
変更後の事実    -> #Git Diff
```

## 2.2 A/B 実験: #Codebase と #File を比較する（10分）

同じ質問を、新しいチャット2つで比較します。まだ変更しません。

### Round A: 広い discovery

```text
#Codebase このアプリが対応する status と、それを説明しているドキュメントを探してください。コードを現行仕様として扱い、根拠 path と symbol を示してください。ファイルは変更しないでください。
```

### Round B: 既知の根拠だけ

`app.py` の `ALLOWED_STATUSES` を選択し、Windows/Linux は `Ctrl+L`、macOS は `Cmd+L` で Ask Kiro へ追加します。次に送ります。

```text
#File app.py #File docs/requirements.md この2ファイルだけを根拠として、status の不一致を表で示してください。コードを現行仕様として扱い、まだ変更しないでください。
```

期待結果: `paused` はドキュメントだけ、`closed` はコードだけにあります。

### 比較スコア

各項目を 0〜2 点で記録します。

| 評価 | Round A | Round B |
|---|---:|---:|
| Relevance: 問いに直接関係する情報 |  |  |
| Completeness: 必要な根拠が揃っている |  |  |
| Noise: 不要な情報が少ないほど高得点 |  |  |
| Verifiability: path / symbol で確認できる |  |  |
| 合計 / 8 |  |  |

`#Codebase` が悪いのではありません。**実装場所を発見した後は、より狭い Context へ切り替える**ことがポイントです。

## 2.3 #Folder: bounded breadth と authority の違い（5分）

まずドキュメントだけを渡します。

```text
#Folder docs/ status、保存形式、CLI option に関する現在の記載を一覧にしてください。まだ正誤は決めず、ファイルは変更しないでください。
```

`#Folder docs/` は複数ドキュメントの横断確認には適しますが、コードを渡していないため、どちらが正しいかは決められません。次に authority を追加します。

```text
#File app.py #File data/jobs.json #Folder docs/ コードとデータを現行仕様として、ドキュメントとの差を status、storage_format、filter_option の3項目で示してください。変更はしないでください。
```

期待結果:

```text
コード: open / closed    ドキュメント: open / paused
コード: JSON             ドキュメント: CSV
コード: --status         ドキュメント: --state
```

## 2.4 最小差分を適用する（7分）

```text
#File app.py #Folder docs/ #File scripts/validate_docs.py validator の3条件を満たす最小差分を提案してください。app.py、data、tests は変更せず、承認したドキュメント差分だけを適用してください。
```

修正後に実行します。

### Windows PowerShell

```powershell
py -3.12 -m unittest discover -s tests -v
py -3.12 scripts/validate_docs.py
py -3.12 app.py --status open
```

### macOS / Linux

```bash
python3 -m unittest discover -s tests -v
python3 scripts/validate_docs.py
python3 app.py --status open
```

## 2.5 #Terminal と #Git Diff: 実行結果と変更結果を分ける（5分）

```text
#Terminal #Git Diff tests と validator の実行結果、変更されたファイル、docs 以外の意図しない変更の有無を報告してください。各結論に Terminal または Git Diff の根拠を付け、ファイルは変更しないでください。
```

確認する違い:

```text
#Terminal -> 実際に何が実行され、成功・失敗したか
#Git Diff -> どのファイルのどの行が変わったか
```

`#Terminal` に長いログ全体を渡す必要はありません。今回の tests と validator の結果だけを選びます。

## 2.6 #Problems: diagnostics 専用の Context（任意3分）

Python diagnostics が利用できる環境だけで実施します。

1. project root に一時ファイル `context_problem_demo.py` を作ります。
2. 次の1行を保存します。

```python
if True print("demo")
```

3. Problems panel に syntax error が表示されたら送ります。

```text
#Problems 表示されている問題の原因と最小修正を説明してください。まだファイルは変更しないでください。
```

4. `context_problem_demo.py` を削除し、`git status --short` が clean であることを確認します。

Problems が表示されない場合は2分以上調査せず、講師画面で用途だけ確認します。`#Problems` はドキュメントの意味のずれではなく、IDE diagnostics を渡す Context です。

## Context の持ち帰り

```text
探索は広く始めてもよい
        |
場所が分かったら狭くする
        |
実行結果と差分を別々に確認する
        |
path / symbol / output で検証できる回答にする
```

# 3. Steering: 再利用するルールを設計する（20分）

## 3.1 分類チャレンジ: template を見る前に決める（5分）

次の rule を `always`、`fileMatch`、`manual`、`今回だけの修正` に分類します。まだ下の template は見ません。

| Rule | 自分の分類 |
|---|---|
| 架空のデータだけを使う |  |
| コードを現行仕様として扱う |  |
| `app.py` の status・保存形式・option を変えたら docs を確認する |  |
| リリース前に tests、validator、Git Diff、CHANGELOG を確認する |  |
| `paused` を `closed` へ修正する |  |
| CSV の記載を JSON へ修正する |  |
| 推測した外部サービスを追加しない |  |

判断軸:

```text
毎回必要                   -> always
特定ファイルを扱う時だけ   -> fileMatch
人が節目で選ぶ review      -> manual
今回直せば終わる事実       -> Steering に置かない
```

分類後、次の3ファイルと比較します。`.kiro/steering/` を作成し、フロントマターの `---` を含めて保存します。

## 3.2 always: プロジェクト全体の前提

`.kiro/steering/project-context.md`

```markdown
---
inclusion: always
---

# プロジェクトの前提

- 対象は架空の Synthetic Job List CLI である。
- Python 3.12 と標準ライブラリだけを使用する。
- 実在の候補者、顧客、個人情報、認証情報、社内リソース ID を追加しない。
- ドキュメントの記載には `app.py`、tests、validator の根拠を付ける。
- 完了前に tests と `scripts/validate_docs.py` を実行する。
- 自動 commit、外部送信、依存関係の追加は行わない。
```

## 3.3 fileMatch: app.py を扱うときだけ

`.kiro/steering/python-doc-sync.md`

```markdown
---
inclusion: fileMatch
fileMatchPattern: "app.py"
---

# コードとドキュメントの同期

- status を変更したら `docs/requirements.md` を確認する。
- データ形式または保存先を変更したら `docs/architecture.md` を確認する。
- CLI option を変更したら `docs/operations.md` を確認する。
- 推測した外部サービスを追加しない。
```

## 3.4 manual: リリース前に明示して使う

`.kiro/steering/release-doc-review.md`

```markdown
---
inclusion: manual
---

# リリース前のドキュメント確認

- [ ] tests が成功
- [ ] `scripts/validate_docs.py` が成功
- [ ] Git Diff に意図しない app、test、data の変更がない
- [ ] 実在の人物、顧客、秘密情報がない
- [ ] `CHANGELOG.md` の Unreleased が更新済み
- [ ] `docs/architecture.drawio` が開ける
```

### 分類の答え合わせ

| 分類 | Rule |
|---|---|
| always | 架空データ、コードを現行仕様とする、推測サービスを追加しない |
| fileMatch | `app.py` の status・保存形式・option 変更時に関連 docs を確認 |
| manual | release 前の tests、validator、Git Diff、CHANGELOG、図 |
| 今回だけの修正 | `paused -> closed`、`CSV -> JSON` |

今回だけの `paused -> closed` や `CSV -> JSON` は Steering に固定しません。それらは今回の修正対象であり、再利用ルールではありません。

まず、manual Steering を選択せずに次を送ります。

```text
現在有効な Steering を always・fileMatch・manual に分けて説明してください。manual の release-doc-review はまだ適用しないでください。app.py を変更する依頼と docs/operations.md だけを変更する依頼で、どの Steering が適用されるか比較してください。ファイルは変更しないでください。
```

次に manual Steering を明示します。

```text
#release-doc-review を適用して、今回の変更がリリース可能か確認してください。tests、validator、Git Diff、機密情報、CHANGELOG、architecture.drawio を Pass / Fail で報告してください。ファイルは変更しないでください。
```

`CHANGELOG.md` が未更新なら Fail または要対応になることを確認し、Unreleased に次を1行追加します。

```markdown
- 開発中のドキュメントを現行実装へ同期。
```

# 4. Agent Hook: 何を自動化するか決める（15分）

## 4.1 自動化境界チャレンジ（5分）

Hook を作る前に、次を `command Hook`、`manual Steering / 人`、`今回は対象外` に分類します。

| 候補 | 自分の判断 | 推奨 |
|---|---|---|
| docs 編集後に validator を実行 |  | command Hook |
| CHANGELOG の文章を自動生成・追記 |  | manual Steering / 人 |
| 読みやすさや意味を評価 |  | 人の review |
| formatter / lint を実行 |  | tool がある project なら command Hook |
| 外部システムへ自動 publish |  | 今回は対象外。権限と承認が必要 |

判断軸:

```text
同じ入力に同じ判定を返せる     -> command Hook の候補
意味・価値・表現の判断が必要   -> Steering / 人
外部への不可逆な action        -> 権限・承認を先に設計
```

この演習では、客観的な3 contract を検査する validator だけを自動化します。

## 4.2 validator Hook を作る（5分）

Agent Hooks から v1 `PostFileSave` Hook を作成します。Windows 参加者は次を `.kiro/hooks/doc-validation.json` として保存します。

```json
{
  "version": "v1",
  "hooks": [
    {
      "name": "validate-docs-after-markdown-save",
      "trigger": "PostFileSave",
      "matcher": "^docs/.*\\.md$",
      "action": {
        "type": "command",
        "command": "py -3.12 scripts/validate_docs.py"
      }
    }
  ]
}
```

macOS / Linux では command だけを次へ置き換えます。

```json
"command": "python3 scripts/validate_docs.py"
```

確認項目:

- `version`: `v1`
- `trigger`: `PostFileSave`
- `matcher`: `^docs/.*\\.md$`
- action type: `command`
- Windows command: `py -3.12 scripts/validate_docs.py`
- macOS / Linux command: `python3 scripts/validate_docs.py`

## 4.3 success -> failure -> recovery を観察する（5分）

Hook の失敗確認で変更する1行:

```markdown
- `storage_format`: `json`
```

一時的な誤変更:

```markdown
- `storage_format`: `csv`
```

次を Kiro Chat へ送り、Hook の失敗を確認します。

```text
Hook の失敗確認です。docs/architecture.md の `storage_format` の値だけを `json` から `csv` へ変更してください。変更するのはその1行だけです。data/jobs.json、app.py、tests、他の記述は変更せず、command も実行しないでください。
```

Hook が validator error を返したら、次を送ります。

```text
docs/architecture.md の `storage_format` の値だけを `csv` から `json` へ戻してください。他のファイルや行は変更しないでください。
```

再び validator が成功することを確認します。`data/jobs.json` のファイル名は変更しません。人が手動保存しただけでは File trigger は発火しません。

# 5. draw.io

`drawio-lab-ja.md` に従い、3要素の編集可能な図を作ります。

```text
User -- --status --> Job List CLI -- read --> data/jobs.json
                         |
                         +-- tab-separated result --> User
```

# 6. Checkpoints

完成状態を参加者本人が commit します。

```bash
git add .
git commit -m "docs: complete workshop exercises"
git status --short
```

Checkpoint で変更する1行:

```markdown
- `filter_option`: `--status`
```

一時的な誤変更:

```markdown
- `filter_option`: `--state`
```

次を Kiro Chat へ送ります。

```text
Checkpoint の復元演習です。docs/operations.md の `filter_option` の値だけを `--status` から `--state` へ変更してください。変更するのはその1行・その1ファイルだけです。Windows/macOS の command example、app.py、tests、data、他のファイルは変更せず、command と commit も実行しないでください。
```

変更後に確認します。

```powershell
git diff -- docs/operations.md
py -3.12 scripts/validate_docs.py
```

誤変更プロンプト直前の Checkpoint から Restore し、次を確認します。

```powershell
git status --short
py -3.12 scripts/validate_docs.py
```

Checkpoint は選んだ時点より後の Agent 変更と会話をまとめて戻します。Git commit とは別の安全網です。

# 7. Q&A・実務への転用

次を自分の業務へ置き換えて記入します。

```text
現在の開発で困っていること:

最初に使う Context と理由:

場所が分かった後に絞る Context:

次回も守る Steering:

機械的に判定できる Hook / validator:

人の判断に残すこと:
```

振り返り:

1. `#Codebase` と targeted Context で何が変わったか
2. Context を減らすことで、何が判断しやすくなったか
3. 毎回繰り返している注意のうち、Steering または Hook に移せるものは何か
4. validator で機械的に判定することと、人がレビューすることをどう分けるか

最後にチャットタブを右クリックして **Export Chat** を選べます。ZIP には会話、コード、path、sub-execution が含まれる可能性があるため、外部共有前に必ず内容を確認します。

# 8. 最終確認

```powershell
py -3.12 -m unittest discover -s tests -v
py -3.12 scripts/validate_docs.py
py -3.12 app.py --status open
```

テストと validator が成功し、`JOB-001` と `JOB-003` が表示されれば完了です。
