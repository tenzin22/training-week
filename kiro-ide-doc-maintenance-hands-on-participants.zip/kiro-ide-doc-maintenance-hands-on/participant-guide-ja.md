# 参加者ガイド: 開発中のコードに合わせてドキュメントを整備する

## ゴール

`app.py` を現行仕様として、必要な Context だけでドキュメントのずれを直し、Steering と Hook で再発を防ぎます。

# 1. Starter Project

Kiro IDE で `starter-project` を開きます。

### Windows PowerShell

```powershell
py -3.12 --version
py -3.12 -m unittest discover -s tests -v
py -3.12 scripts/validate_docs.py
py -3.12 app.py
```

### macOS / Linux

```bash
python3 --version
python3 -m unittest discover -s tests -v
python3 scripts/validate_docs.py
python3 app.py
```

開始状態ではテスト3件が成功し、validator は次の3件を報告します。

```text
コード: status は open / closed    ドキュメント: open / paused
コード: JSON                       ドキュメント: CSV
コード: --status                   ドキュメント: --state
```

この時点ではファイルを変更しません。

## Git baseline

Checkpoint 自体は Git 不要ですが、`#Git Diff` のため参加者本人が初期 commit を作ります。

```bash
git init -b main
git config user.name "Kiro Workshop Participant"
git config user.email "kiro-workshop@example.invalid"
git add .
git commit -m "chore: establish workshop baseline"
git status --short
```

# 2. Context: 必要な根拠だけを渡す

## 2.1 status のずれ

`app.py` の `ALLOWED_STATUSES` と `docs/requirements.md` を Context に追加します。

```text
#File app.py #File docs/requirements.md この2ファイルだけを根拠として、status の不一致を表で示してください。コードを現行仕様として扱い、まだ変更しないでください。
```

期待結果: `paused` はドキュメントだけ、`closed` はコードだけにあります。

## 2.2 保存形式のずれ

```text
#File app.py #File data/jobs.json #File docs/architecture.md 保存形式について「ドキュメントの記載」「コードの事実」「必要な修正」を示してください。変更はしないでください。
```

期待結果: ドキュメントは CSV、コードとデータは JSON です。

## 2.3 CLI option のずれを含めて修正

```text
#File app.py #Folder docs/ #File scripts/validate_docs.py validator の3条件を満たす最小差分を提案してください。app.py、data、tests は変更せず、承認したドキュメント差分だけを適用してください。
```

修正後に実行します。

```powershell
py -3.12 -m unittest discover -s tests -v
py -3.12 scripts/validate_docs.py
py -3.12 app.py --status open
```

macOS / Linux は `py -3.12` を `python3` に置き換えます。

# 3. Steering: 再利用するルールを保存する

`.kiro/steering/` に3種類を作ります。

- `project-context.md`: `inclusion: always`。合成データ、コードを正とする、完了前のテストと validator
- `python-doc-sync.md`: `inclusion: fileMatch`、`fileMatchPattern: "app.py"`。status、保存形式、CLI option を変えたら対応ドキュメントを確認
- `release-doc-review.md`: `inclusion: manual`。tests、validator、Git Diff、機密情報、CHANGELOG、図を確認

今回だけの `paused -> closed` や `CSV -> JSON` を Steering に固定しません。それらは修正対象であり、再利用ルールではありません。

manual Steering を明示して Pass / Fail を報告させ、`CHANGELOG.md` の Unreleased に次を1行追加します。

```text
- 開発中のドキュメントを現行実装へ同期。
```

# 4. Agent Hook: 編集後に同じ検証を実行する

Agent Hooks から v1 `PostFileSave` Hook を作ります。

- matcher: `^docs/.*\.md$`
- Windows command: `py -3.12 scripts/validate_docs.py`
- macOS / Linux command: `python3 scripts/validate_docs.py`

Kiro Agent に `docs/architecture.md` の JSON を一時的に CSV へ変更させ、Hook の失敗を確認します。その1行を戻し、再び成功することを確認します。人が手動保存しただけでは File trigger は発火しません。

# 5. draw.io

`drawio-lab-ja.md` に従い、3要素の編集可能な図を作ります。

```text
User -- --status --> Job List CLI -- read --> data/jobs.json
                         |
                         +-- tab-separated result --> User
```

# 6. Checkpoints

完成状態を参加者本人が commit します。

```bash
git add .
git commit -m "docs: complete workshop exercises"
git status --short
```

Kiro Agent に `docs/operations.md` の正しい `--status` を意図的に `--state` へ変更させます。変更はその1ファイルだけに限定します。

```powershell
git diff -- docs/operations.md
py -3.12 scripts/validate_docs.py
```

誤変更プロンプト直前の Checkpoint から Restore し、次を確認します。

```powershell
git status --short
py -3.12 scripts/validate_docs.py
```

Checkpoint は選んだ時点より後の Agent 変更と会話をまとめて戻します。Git commit とは別の安全網です。

# 7. 最終確認

```powershell
py -3.12 -m unittest discover -s tests -v
py -3.12 scripts/validate_docs.py
py -3.12 app.py --status open
```

テストと validator が成功し、`JOB-001` と `JOB-003` が表示されれば完了です。
