# 参加者ガイド: 開発中のコードに合わせてドキュメントを整備する

## ゴール

`app.py` を現行仕様として、必要な Context だけでドキュメントのずれを直し、Steering と Hook で再発を防ぎます。

## タイムテーブル

| 内容 | 時間 |
|---|---:|
| 講義 | 25分 |
| Starter Project | 5分 |
| Context | 20分 |
| Steering | 25分 |
| Agent Hooks | 20分 |
| 休憩 | 10分 |
| draw.io | 25分 |
| Checkpoints | 5分 |
| Q&A・振り返り | 15分 |

各章で「予測する -> 実行する -> 結果を見る -> 次回も効く仕組みにする」を繰り返します。

# 1. Starter Project

Kiro IDE で `starter-project` を開きます。

### Windows PowerShell

```powershell
py -3.12 --version
py -3.12 -m unittest discover -s tests -v
py -3.12 scripts/validate_docs.py
py -3.12 app.py
```

### macOS / Linux

```bash
python3 --version
python3 -m unittest discover -s tests -v
python3 scripts/validate_docs.py
python3 app.py
```

開始状態ではテスト3件が成功し、validator は次の3件を報告します。

```text
コード: status は open / closed    ドキュメント: open / paused
コード: JSON                       ドキュメント: CSV
コード: --status                   ドキュメント: --state
```

この時点ではファイルを変更しません。

## Git baseline

Checkpoint 自体は Git 不要ですが、`#Git Diff` のため参加者本人が初期 commit を作ります。

```bash
git init -b main
git config user.name "Kiro Workshop Participant"
git config user.email "kiro-workshop@example.invalid"
git add .
git commit -m "chore: establish workshop baseline"
git status --short
```

`git status --short` に何も表示されれば合格です。

## 1.1 画面配置

1. Kiro のチャットタブを右クリックします。
2. **Open in Editor** を選び、Dockable Chat をコードやドキュメントの横へ配置します。
3. 利用できない場合は通常のチャットパネルのまま続けます。

# 2. Context: 必要な根拠だけを渡す

## 2.1 status のずれ

`app.py` の `ALLOWED_STATUSES` と `docs/requirements.md` を Context に追加します。

```text
#File app.py #File docs/requirements.md この2ファイルだけを根拠として、status の不一致を表で示してください。コードを現行仕様として扱い、まだ変更しないでください。
```

期待結果: `paused` はドキュメントだけ、`closed` はコードだけにあります。

## 2.2 保存形式のずれ

```text
#File app.py #File data/jobs.json #File docs/architecture.md 保存形式について「ドキュメントの記載」「コードの事実」「必要な修正」を示してください。変更はしないでください。
```

期待結果: ドキュメントは CSV、コードとデータは JSON です。

## 2.3 CLI option のずれを含めて修正

```text
#File app.py #Folder docs/ #File scripts/validate_docs.py validator の3条件を満たす最小差分を提案してください。app.py、data、tests は変更せず、承認したドキュメント差分だけを適用してください。
```

修正後に実行します。

```powershell
py -3.12 -m unittest discover -s tests -v
py -3.12 scripts/validate_docs.py
py -3.12 app.py --status open
```

macOS / Linux は `py -3.12` を `python3` に置き換えます。

## 2.4 Context の使い分け

| Context | 使う場面 |
|---|---|
| Ask Kiro | `app.py` の `ALLOWED_STATUSES` など、選択したコードを現在のチャットへ渡す |
| `#File` | 根拠となる1ファイルが分かっている |
| `#Folder` | `docs/` のように対象フォルダーが明確 |
| `#Codebase` | どのファイルに実装があるか分からず、workspace 全体から探したい |
| `#Problems` | IDE が検出した syntax・type・import error を渡す |
| `#Terminal` | tests や validator の実行結果を根拠として渡す |
| `#Git Diff` | 適用後の変更範囲と意図しない変更を確認する |

Windows/Linux はコードを選択して `Ctrl+L`、macOS は `Cmd+L` で現在の Ask Kiro chat へ追加できます。最初から `#Codebase` を使うのではなく、分かっている `#File` や選択範囲から始めます。

次を送って、変更対象と変更しない対象を確認します。

```text
#Terminal #Git Diff 実行結果と差分を確認し、docs 以外の変更がないこと、tests と validator の結果を根拠付きで報告してください。ファイルは変更しないでください。
```

# 3. Steering: 再利用するルールを保存する

`.kiro/steering/` を作成し、次の3ファイルをそのまま保存します。フロントマターの `---` も必要です。

## 3.1 always: プロジェクト全体の前提

`.kiro/steering/project-context.md`

```markdown
---
inclusion: always
---

# プロジェクトの前提

- 対象は架空の Synthetic Job List CLI である。
- Python 3.12 と標準ライブラリだけを使用する。
- 実在の候補者、顧客、個人情報、認証情報、社内リソース ID を追加しない。
- ドキュメントの記載には `app.py`、tests、validator の根拠を付ける。
- 完了前に tests と `scripts/validate_docs.py` を実行する。
- 自動 commit、外部送信、依存関係の追加は行わない。
```

## 3.2 fileMatch: app.py を扱うときだけ

`.kiro/steering/python-doc-sync.md`

```markdown
---
inclusion: fileMatch
fileMatchPattern: "app.py"
---

# コードとドキュメントの同期

- status を変更したら `docs/requirements.md` を確認する。
- データ形式または保存先を変更したら `docs/architecture.md` を確認する。
- CLI option を変更したら `docs/operations.md` を確認する。
- 推測した外部サービスを追加しない。
```

## 3.3 manual: リリース前に明示して使う

`.kiro/steering/release-doc-review.md`

```markdown
---
inclusion: manual
---

# リリース前のドキュメント確認

- [ ] tests が成功
- [ ] `scripts/validate_docs.py` が成功
- [ ] Git Diff に意図しない app、test、data の変更がない
- [ ] 実在の人物、顧客、秘密情報がない
- [ ] `CHANGELOG.md` の Unreleased が更新済み
- [ ] `docs/architecture.drawio` が開ける
```

今回だけの `paused -> closed` や `CSV -> JSON` は Steering に固定しません。それらは今回の修正対象であり、再利用ルールではありません。

まず、manual Steering を選択せずに次を送ります。

```text
現在有効な Steering を always・fileMatch・manual に分けて説明してください。manual の release-doc-review はまだ適用しないでください。app.py を変更する依頼と docs/operations.md だけを変更する依頼で、どの Steering が適用されるか比較してください。ファイルは変更しないでください。
```

次に manual Steering を明示します。

```text
#release-doc-review を適用して、今回の変更がリリース可能か確認してください。tests、validator、Git Diff、機密情報、CHANGELOG、architecture.drawio を Pass / Fail で報告してください。ファイルは変更しないでください。
```

`CHANGELOG.md` が未更新なら Fail または要対応になることを確認し、Unreleased に次を1行追加します。

```markdown
- 開発中のドキュメントを現行実装へ同期。
```

# 4. Agent Hook: 編集後に同じ検証を実行する

Agent Hooks から v1 `PostFileSave` Hook を作成します。Windows 参加者は次を `.kiro/hooks/doc-validation.json` として保存します。

```json
{
  "version": "v1",
  "hooks": [
    {
      "name": "validate-docs-after-markdown-save",
      "trigger": "PostFileSave",
      "matcher": "^docs/.*\\.md$",
      "action": {
        "type": "command",
        "command": "py -3.12 scripts/validate_docs.py"
      }
    }
  ]
}
```

macOS / Linux では command だけを次へ置き換えます。

```json
"command": "python3 scripts/validate_docs.py"
```

確認項目:

- `version`: `v1`
- `trigger`: `PostFileSave`
- `matcher`: `^docs/.*\\.md$`
- action type: `command`
- Windows command: `py -3.12 scripts/validate_docs.py`
- macOS / Linux command: `python3 scripts/validate_docs.py`

Hook の失敗確認で変更する1行:

```markdown
- `storage_format`: `json`
```

一時的な誤変更:

```markdown
- `storage_format`: `csv`
```

次を Kiro Chat へ送り、Hook の失敗を確認します。

```text
Hook の失敗確認です。docs/architecture.md の `storage_format` の値だけを `json` から `csv` へ変更してください。変更するのはその1行だけです。data/jobs.json、app.py、tests、他の記述は変更せず、command も実行しないでください。
```

Hook が validator error を返したら、次を送ります。

```text
docs/architecture.md の `storage_format` の値だけを `csv` から `json` へ戻してください。他のファイルや行は変更しないでください。
```

再び validator が成功することを確認します。`data/jobs.json` のファイル名は変更しません。人が手動保存しただけでは File trigger は発火しません。

# 5. draw.io

`drawio-lab-ja.md` に従い、3要素の編集可能な図を作ります。

```text
User -- --status --> Job List CLI -- read --> data/jobs.json
                         |
                         +-- tab-separated result --> User
```

# 6. Checkpoints

完成状態を参加者本人が commit します。

```bash
git add .
git commit -m "docs: complete workshop exercises"
git status --short
```

Checkpoint で変更する1行:

```markdown
- `filter_option`: `--status`
```

一時的な誤変更:

```markdown
- `filter_option`: `--state`
```

次を Kiro Chat へ送ります。

```text
Checkpoint の復元演習です。docs/operations.md の `filter_option` の値だけを `--status` から `--state` へ変更してください。変更するのはその1行・その1ファイルだけです。Windows/macOS の command example、app.py、tests、data、他のファイルは変更せず、command と commit も実行しないでください。
```

変更後に確認します。

```powershell
git diff -- docs/operations.md
py -3.12 scripts/validate_docs.py
```

誤変更プロンプト直前の Checkpoint から Restore し、次を確認します。

```powershell
git status --short
py -3.12 scripts/validate_docs.py
```

Checkpoint は選んだ時点より後の Agent 変更と会話をまとめて戻します。Git commit とは別の安全網です。

# 7. Q&A・振り返り

次の3問を自分の業務へ置き換えて考えます。

1. Context を絞ることで、何が判断しやすくなったか
2. 毎回繰り返している注意のうち、Steering または Hook に移せるものは何か
3. validator で機械的に判定することと、人がレビューすることをどう分けるか

最後にチャットタブを右クリックして **Export Chat** を選べます。ZIP には会話、コード、path、sub-execution が含まれる可能性があるため、外部共有前に必ず内容を確認します。

# 8. 最終確認

```powershell
py -3.12 -m unittest discover -s tests -v
py -3.12 scripts/validate_docs.py
py -3.12 app.py --status open
```

テストと validator が成功し、`JOB-001` と `JOB-003` が表示されれば完了です。
