# draw.io 統合ラボ - 25 分

## 目的と完了条件

現行実装だけを根拠に、次を作成します。

- `docs/architecture.drawio`
- `docs/architecture.md` からの相対リンク
- 4 要素だけの構成図: `User`、`CLI`、`DocumentRegistry`、`data/documents.json`
- 操作フロー `list --category / --status` とデータ読み取り `read`

禁止事項:

- AWS サービス、DB、API、認証基盤など、実装にない要素を追加しない
- 顧客名、個人名、認証情報、社内リソース ID を含めない
- 公式 `@drawio/mcp` 以外の未確認 server、Power、ツールを追加しない
- コードを変更しない

## 共通の根拠確認 - 3 分

Kiro IDE のチャットで `#File`、`#Folder`、`#Codebase` の候補を選び、次を送ります。

```text
#File docs/architecture.md #Folder src/document_registry/ #File data/documents.json #Codebase 現行実装だけを根拠に構成図の仕様を作ってください。要素は User、CLI、DocumentRegistry、data/documents.json の4つだけにし、list --category / --status と read の向きを示してください。推測したサービスは追加せず、根拠ファイルとシンボル名を併記してください。まだファイルを変更しないでください。
```

合格する仕様:

| From | To | Label | 根拠 |
|---|---|---|---|
| User | CLI | `list --category / --status` | `build_parser`, `main` |
| CLI | DocumentRegistry | `from_json / list_documents` | `cli.py`, `registry.py` |
| DocumentRegistry | `data/documents.json` | `read` | `DocumentRegistry.from_json` |
| CLI | User | `tab-separated result` | `main` |

ここから Track A または Track B の一方だけを実施します。

---

## Track A - 公式 `@drawio/mcp` - 17 分

### A1. 接続とツールを確認する - 3 分

1. MCP Servers パネルを開く。
2. `drawio` の status が `Connected` であることを確認する。
3. tool 一覧に `open_drawio_mermaid` が表示されることを確認する。
4. 接続できない、または tool が表示されない場合は 5 分以上調査せず Track B へ切り替える。

設定手順は `prerequisites-ja.md` の「draw.io MCP の事前準備」を参照します。

### A2. Mermaid を作成し、MCP で開く - 8 分

次を送ります。使用するツール名を明示し、図の根拠と要素数を限定します。

```text
#File docs/architecture.md #Folder src/document_registry/ #File data/documents.json 現行実装だけを根拠に Mermaid flowchart LR を作成し、drawio MCP の open_drawio_mermaid を使って draw.io で開いてください。要素は User、CLI、DocumentRegistry、data/documents.json の4つだけです。UserからCLIは list --category / --status、CLIからDocumentRegistryは from_json / list_documents、DocumentRegistryからJSONは read、CLIからUserは tab-separated result と表示してください。顧客名、個人名、認証情報、推測上のサービスを含めないでください。コードと既存ファイルは変更しないでください。
```

権限プロンプトでは、server が `drawio`、tool が `open_drawio_mermaid` であることを確認し、1 回限りの `Allow` を選びます。想定外のファイル、shell、資格情報、または別の外部送信を要求した場合は `Deny` して Track B へ切り替えます。

期待される結果:

- ブラウザー版 draw.io が新しいタブで開く
- 4 ノードと 4 本の矢印が表示される
- 図は編集可能である

### A3. workspace へ保存する - 3 分

1. draw.io の `File > Save As` を選ぶ。
2. 保存先として Device を選ぶ。
3. `docs/architecture.drawio` として `starter-project` 内へ保存する。
4. Kiro IDE の Explorer にファイルが表示されることを確認する。

ブラウザーから `starter-project/docs/` へ直接保存できない場合は、既定の Downloads フォルダーへ保存してから、Kiro IDE の Explorer で `docs/` へ移動します。

### A4. Markdown を同期する - 3 分

```text
#File docs/architecture.md #File docs/architecture.drawio docs/architecture.md の Overview 直後に [構成図](architecture.drawio) の相対リンクを1行追加してください。既存の実装説明は validator の期待値に合わせ、コードは変更しないでください。
```

---

## Track B - Mermaid / 構造化仕様フォールバック - 17 分

### B1. Mermaid を生成する - 5 分

```text
#File docs/architecture.md #Folder src/document_registry/ #File data/documents.json draw.io に取り込む Mermaid flowchart LR をコードブロック1つだけで返してください。ノードは User、CLI、DocumentRegistry、data/documents.json の4つだけにしてください。矢印ラベルは list --category / --status、list_documents、read、tab-separated result を使用してください。ファイルは変更しないでください。
```

期待する構造の例:

```mermaid
flowchart LR
    U[User] -->|list --category / --status| C[CLI]
    C -->|from_json / list_documents| R[DocumentRegistry]
    R -->|read| J[(data/documents.json)]
    C -->|tab-separated result| U
```

### B2. draw.io へ取り込む - 7 分

1. draw.io で新規 Blank Diagram を開く。
2. `Arrange > Insert > Mermaid`、または toolbar の `+ > Mermaid` を選ぶ。
3. Mermaid source を貼り付け、既定の `Diagram` を選び `Insert` する。
4. 4 ノードと 4 本の矢印、各ラベルを目視確認する。
5. `File > Save As` で `docs/architecture.drawio` に保存する。

Mermaid import が利用できない場合は、上の表を構造化図面仕様として手作業で再現します。要素、矢印、ラベルを増減しません。

### B3. Markdown を同期する - 5 分

Track A の A4 と同じプロンプトを使用します。

---

## 共通検証 - 5 分

1. Explorer から `docs/architecture.drawio` を開ける、または draw.io の `File > Open From > Device` で開ける。
2. 4 要素、4 フロー、ラベルを確認する。
3. `docs/architecture.md` の相対リンクを選択し、対象ファイルを開けることを確認する。
4. Kiro IDE 内蔵 Terminal で実行する。

```bash
PYTHONPATH=src python3 -m unittest discover -s tests -v
python3 scripts/validate_docs.py
```

5. `#Git Diff` で次を確認する。

```text
#Git Diff draw.io と Markdown の差分だけをレビューしてください。4要素が現行コードと一致すること、推測したサービスがないこと、機密情報がないこと、コード変更がないことを確認してください。
```

合格:

- `.drawio` が再度開ける
- User -> CLI -> DocumentRegistry -> JSON の主経路がある
- `list --category / --status`、対応メソッド、`read`、`tab-separated result` が読める
- validator と 4 テストが成功する
- 図と Markdown 以外の意図しない変更がない

失敗時:

- Track A の接続または権限で失敗: 5 分を超えて調査せず Track B
- Mermaid import で失敗: 構造化仕様を手作業で再現
- `.drawio` を再度開けない: Save As をやり直し、拡張子と保存先を確認
- validator が失敗: 図ではなく該当 Markdown の古い記述を修正
