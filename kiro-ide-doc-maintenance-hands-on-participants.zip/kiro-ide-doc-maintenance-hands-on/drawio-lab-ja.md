# draw.io 統合ラボ

## 目的

現行コードだけを根拠に、3要素・3フローの編集可能な `docs/architecture.drawio` を作ります。

```text
User -- --status --> Job List CLI -- read --> data/jobs.json
                         |
                         +-- tab-separated result --> User
```

推測した DB、API、認証、AWS サービス、実在の会社名や人物を追加しません。

## 根拠確認

```text
#File app.py #File data/jobs.json #File docs/architecture.md 現行実装だけを根拠に、User、Job List CLI、data/jobs.json の3要素と3フローを表にしてください。まだ変更しないでください。
```

| From | To | Label | 根拠 |
|---|---|---|---|
| User | Job List CLI | `--status` | `main` |
| Job List CLI | `data/jobs.json` | `read` | `load_jobs` |
| Job List CLI | User | `tab-separated result` | `main` |

## Track A: 公式 `@drawio/mcp`

MCP Servers で `drawio` が Connected、tool が `open_drawio_mermaid` であることを確認します。5分以上かかる場合は Track B へ切り替えます。

```text
#File app.py #File data/jobs.json 現行実装だけを根拠に Mermaid flowchart LR を作り、drawio MCP の open_drawio_mermaid で開いてください。要素は User、Job List CLI、data/jobs.json の3つだけです。矢印は --status、read、tab-separated result の3本です。コードや既存ファイルを変更しないでください。
```

権限画面で server=`drawio`、tool=`open_drawio_mermaid` を確認し、1回限りの Allow を選びます。

## Track B: Mermaid fallback

```mermaid
flowchart LR
    U[User] -->|--status| C[Job List CLI]
    C -->|read| J[(data/jobs.json)]
    C -->|tab-separated result| U
```

これを draw.io の Mermaid import へ貼り付けるか、同じ3要素を手作業で再現します。

## 保存と同期

1. `docs/architecture.drawio` として保存する
2. `docs/architecture.md` の Overview 直後に `[構成図](architecture.drawio)` を追加する
3. 図を閉じて再度開けることを確認する

## 検証

### Windows

```powershell
py -3.12 -m unittest discover -s tests -v
py -3.12 scripts/validate_docs.py
```

### macOS / Linux

```bash
python3 -m unittest discover -s tests -v
python3 scripts/validate_docs.py
```

`#Git Diff` で、図と Markdown 以外のコード変更がないこと、3要素・3フローが `app.py` と一致することを確認します。
