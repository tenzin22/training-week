# Kiro IDE ハンズオン: 開発中のドキュメント整備

架空の「Project Document Registry」を題材に、実装とドキュメントのずれを Kiro IDE で発見し、再発防止まで設定する参加者向けパッケージです。

## シナリオ

開発中の社内文書レジストリではコード変更が先行し、要件・アーキテクチャ・運用手順が古くなっています。参加者は対象コンテキストを絞って差分を調べ、Steering で判断基準を固定し、Agent Hooks で検証を繰り返せる状態にします。データ、人物、識別子はすべて架空です。

## 構成

- `participant-guide-ja.md`: 参加者向け進行、正確なプロンプト、期待される観察結果
- `starter-project/`: Python 3.12、外部依存なしの演習用プロジェクト
- `drawio-lab-ja.md`: draw.io 演習。別担当が作成する資料を参照します

## 所要時間

合計 150 分です。

| セクション | 時間 |
|---|---:|
| 講義 | 25分 |
| Starter Project | 5分 |
| Context | 20分 |
| Steering | 25分 |
| Agent Hooks | 20分 |
| 休憩 | 10分 |
| draw.io | 25分 |
| Checkpoints | 5分 |
| Q&A | 15分 |

## 開始状態と完了条件

開始時点ではユニットテストは成功しますが、ドキュメント検証は既知の3件を報告して終了コード1になります。続いてローカル Git repository と初期 commit を参加者本人が作成し、以降の `#Git Diff` と Source Control の基準点にします。Checkpoint 自体は Git に依存しません。

```bash
cd starter-project
python3 -m unittest discover -s tests -v
python3 scripts/validate_docs.py
```

完了時は次を満たします。

- テストが成功する
- ドキュメント検証が終了コード0になる
- always、fileMatch、manual の3種類の Steering を使い分けられる
- Agent Hook から同じ検証を再実行できる
- draw.io 図と本文の境界を説明できる
- Checkpoint から安全に復元できる
