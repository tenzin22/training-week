# Kiro IDE 中級編: 開発中のコードに合わせたドキュメント整備

架空の「Synthetic Job List CLI」を題材に、開発中のコードを正としてドキュメントのずれを直し、再発を防ぐハンズオンです。

## 学習の流れ

1. Starter: テスト成功と validator の3件失敗を観察
2. Context: 必要なコードとドキュメントだけを比較
3. Steering: 再利用する判断基準を適用範囲別に保存
4. Agent Hooks: ドキュメント編集後に validator を自動実行
5. draw.io: `User -> Job List CLI -> jobs.json` を可視化
6. Checkpoints: 意図的な誤変更を Restore

Python 3.12 標準ライブラリだけを使います。データはすべて架空です。
