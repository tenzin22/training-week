# Project Document Registry

社内プロジェクト文書を検索する架空の Python 3.12 アプリケーションです。外部パッケージは使用しません。

## 実行

```bash
python3 -m unittest discover -s tests -v
python3 scripts/validate_docs.py
PYTHONPATH=src python3 -m document_registry.cli --data data/documents.json list
```

開始状態ではテストは成功し、文書バリデータは意図的に3件の不整合を報告します。演習では実装を変更せず、`docs/` の最小差分で解消します。

## 構成

- `src/document_registry/`: レジストリ実装と CLI
- `tests/`: 標準ライブラリ `unittest` のテスト
- `data/`: 架空の文書メタデータ
- `docs/`: 意図的に古い記述を含む文書
- `scripts/validate_docs.py`: 実装と文書の整合性検証

## Git baseline

`#Git Diff` と Source Control を使うため、テストと初期 validator の確認後、参加者本人が次を実行します。Checkpoint 自体は Git に依存しません。

```bash
git init -b main
git config user.name "Kiro Workshop Participant"
git config user.email "kiro-workshop@example.invalid"
git add .
git commit -m "chore: establish workshop baseline"
git status --short
```

`.gitignore` により Python の生成キャッシュは初期 commit に含まれません。
