# Requirements

## Purpose

The Project Document Registry lets an internal project team list and find document metadata during development.

## Supported metadata

- `category`: `design`, `runbook`, `plan`
- `status`: `draft`, `review`, `published`
- Every record has a document ID, title, category, owner, and status.

## Constraints

- Examples must remain synthetic.
- A request with an unsupported category must fail validation.
- Search may filter by category or status.
