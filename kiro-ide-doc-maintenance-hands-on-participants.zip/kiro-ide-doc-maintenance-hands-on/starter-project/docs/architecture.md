# Architecture

## Components

1. The CLI receives a data path and optional filters.
2. `DocumentRegistry` loads document metadata.
3. The registry validates categories and statuses.
4. Query methods return matching immutable records.

## Storage

The starter implementation reads document metadata from a CSV file. Storage is local so the workshop does not require network access.

## Boundaries

- The project does not provide authentication or authorization.
- The project does not connect to production systems.
- All records are fictional workshop data.
