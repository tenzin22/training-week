# Operations

## Local verification

Run tests from the project root:

```bash
python3 -m unittest
```

Run the documentation consistency check:

```bash
python3 scripts/validate_docs.py
```

## Query example

```bash
PYTHONPATH=src python3 -m document_registry.cli --data data/documents.json list --status published
```

A successful command prints tab-separated document metadata. This training project has no network or production dependencies.
