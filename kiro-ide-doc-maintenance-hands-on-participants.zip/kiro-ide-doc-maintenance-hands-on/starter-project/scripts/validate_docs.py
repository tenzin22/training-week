#!/usr/bin/env python3
"""Deterministically check documentation against implementation contracts."""

from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from document_registry.registry import ALLOWED_CATEGORIES, STORAGE_FORMAT  # noqa: E402


def validate() -> list[str]:
    docs = PROJECT_ROOT / "docs"
    requirements = (docs / "requirements.md").read_text(encoding="utf-8")
    architecture = (docs / "architecture.md").read_text(encoding="utf-8")
    operations = (docs / "operations.md").read_text(encoding="utf-8")

    issues: list[str] = []
    category_line = next(
        (line for line in requirements.splitlines() if line.startswith("- `category`:")),
        "",
    )
    missing_categories = [
        category for category in sorted(ALLOWED_CATEGORIES) if f"`{category}`" not in category_line
    ]
    extra_categories = [
        category
        for category in ("plan", "memo")
        if f"`{category}`" in category_line and category not in ALLOWED_CATEGORIES
    ]
    if missing_categories or extra_categories:
        issues.append(
            "docs/requirements.md: category list differs from code "
            f"(missing={missing_categories}, extra={extra_categories})"
        )

    if STORAGE_FORMAT.upper() not in architecture.upper():
        issues.append(
            "docs/architecture.md: storage format must identify JSON used by the implementation"
        )

    test_command = "python3 -m unittest discover -s tests -v"
    if test_command not in operations:
        issues.append(
            "docs/operations.md: test command must be " + test_command
        )

    return issues


def main() -> int:
    issues = validate()
    if issues:
        print(f"Documentation validation found {len(issues)} known issue(s):")
        for issue in issues:
            print(f"- {issue}")
        return 1
    print("Documentation validation passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
