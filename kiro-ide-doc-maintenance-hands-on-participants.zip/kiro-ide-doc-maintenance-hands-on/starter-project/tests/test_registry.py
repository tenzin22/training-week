from pathlib import Path
import sys
import tempfile
import unittest

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from document_registry import DocumentRegistry  # noqa: E402


class DocumentRegistryTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.registry = DocumentRegistry.from_json(PROJECT_ROOT / "data" / "documents.json")

    def test_loads_synthetic_documents(self) -> None:
        self.assertEqual(4, len(self.registry.list_documents()))

    def test_filters_by_category(self) -> None:
        decisions = self.registry.list_documents(category="decision")
        self.assertEqual(["ADR-014"], [item.document_id for item in decisions])

    def test_finds_document_by_id(self) -> None:
        document = self.registry.find_by_id("RUN-007")
        self.assertIsNotNone(document)
        self.assertEqual("Registry recovery drill", document.title)

    def test_rejects_unknown_category(self) -> None:
        invalid_json = (
            '{"documents":[{"document_id":"TMP-001","title":"Synthetic",'
            '"category":"memo","owner":"Example Team","status":"draft"}]}'
        )
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "invalid.json"
            path.write_text(invalid_json, encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Unsupported category: memo"):
                DocumentRegistry.from_json(path)


if __name__ == "__main__":
    unittest.main()
