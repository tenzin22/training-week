# Changelog

## Unreleased

- No user-visible changes recorded yet.

## 0.1.0 - 2026-09-03

- Added the synthetic Project Document Registry starter project.
