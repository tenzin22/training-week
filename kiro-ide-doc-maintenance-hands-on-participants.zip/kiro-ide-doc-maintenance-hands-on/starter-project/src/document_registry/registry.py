"""Load and query project-document metadata."""

import json
from pathlib import Path

from .models import Document

ALLOWED_CATEGORIES = frozenset({"design", "runbook", "decision"})
ALLOWED_STATUSES = frozenset({"draft", "review", "published"})
STORAGE_FORMAT = "json"


class DocumentRegistry:
    def __init__(self, documents: list[Document]) -> None:
        self._documents = tuple(documents)

    @classmethod
    def from_json(cls, path: Path) -> "DocumentRegistry":
        payload = json.loads(path.read_text(encoding="utf-8"))
        documents = [Document.from_dict(item) for item in payload["documents"]]
        for document in documents:
            if document.category not in ALLOWED_CATEGORIES:
                raise ValueError(f"Unsupported category: {document.category}")
            if document.status not in ALLOWED_STATUSES:
                raise ValueError(f"Unsupported status: {document.status}")
        return cls(documents)

    def list_documents(
        self,
        *,
        category: str | None = None,
        status: str | None = None,
    ) -> list[Document]:
        return [
            document
            for document in self._documents
            if (category is None or document.category == category)
            and (status is None or document.status == status)
        ]

    def find_by_id(self, document_id: str) -> Document | None:
        return next(
            (
                document
                for document in self._documents
                if document.document_id == document_id
            ),
            None,
        )
