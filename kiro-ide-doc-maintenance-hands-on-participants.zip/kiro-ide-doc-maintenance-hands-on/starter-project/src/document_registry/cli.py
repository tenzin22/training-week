"""Command-line interface for the synthetic registry."""

import argparse
from pathlib import Path

from .registry import ALLOWED_CATEGORIES, DocumentRegistry


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="List project documents")
    parser.add_argument("--data", type=Path, required=True)
    subparsers = parser.add_subparsers(dest="command", required=True)
    list_parser = subparsers.add_parser("list", help="List matching documents")
    list_parser.add_argument("--category", choices=sorted(ALLOWED_CATEGORIES))
    list_parser.add_argument("--status", choices=["draft", "review", "published"])
    return parser


def main() -> int:
    args = build_parser().parse_args()
    registry = DocumentRegistry.from_json(args.data)
    documents = registry.list_documents(category=args.category, status=args.status)
    for document in documents:
        print(
            f"{document.document_id}\t{document.category}\t"
            f"{document.status}\t{document.title}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
