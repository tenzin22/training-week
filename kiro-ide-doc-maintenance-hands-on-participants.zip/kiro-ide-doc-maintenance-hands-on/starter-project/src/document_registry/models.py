"""Domain model for synthetic project documents."""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Document:
    document_id: str
    title: str
    category: str
    owner: str
    status: str

    @classmethod
    def from_dict(cls, value: dict[str, str]) -> "Document":
        return cls(
            document_id=value["document_id"],
            title=value["title"],
            category=value["category"],
            owner=value["owner"],
            status=value["status"],
        )
