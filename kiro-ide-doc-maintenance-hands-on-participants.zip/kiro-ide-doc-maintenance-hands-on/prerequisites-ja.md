# 事前準備 - Kiro IDE 1.x

確認日: 2026-09-03

## 必須環境

- Kiro IDE 1.x をインストールし、サインイン済みであること
- `starter-project` を Kiro IDE の `File > Open Folder` で開けること
- Kiro パネルの Steering、Agent Hooks、MCP Servers、Powers を表示できること
- Kiro IDE 内蔵 Terminal で Python 3.12 を実行できること
- draw.io Desktop または [draw.io Web](https://app.diagrams.net/) で `.drawio` を開いて保存できること
- 追加依存関係、顧客データ、認証情報を演習へ持ち込まないこと

本演習は Kiro IDE 専用です。CLI 専用の Tool Search や CLI の操作説明は使用しません。Terminal はスタータープロジェクトのテストと validator 実行にだけ使用します。

## 開始前チェック

Kiro IDE 内蔵 Terminal で、`starter-project` をカレントフォルダーとして実行します。

```bash
python3 --version
PYTHONPATH=src python3 -m unittest discover -s tests -v
python3 scripts/validate_docs.py
```

開始状態の合格条件:

- Python は 3.12 系
- 4 件の単体テストは `OK`
- validator は終了コード 1 で、要件の category、構成の storage format、運用の test command の 3 件を表示
- validator 失敗は意図した教材状態であり、アプリケーション障害ではない

## Kiro IDE 1.x の安全設定

1. `Settings > Agent > Agent Autonomy` を確認する。
2. 初回実施は `Supervised` を推奨する。
3. ファイル書き込み、コマンド、MCP ツールの承認画面では、まず 1 回限りの `Allow` を選ぶ。
4. `Always allow` を選ぶ場合は、対象ツールとこの workspace に範囲を限定する。
5. `.env`、鍵、資格情報、外部送信、自動コミットを許可しない。

Kiro IDE 1.x は capability-based permissions を使用します。未許可の書き込み、コマンド、MCP 呼び出しは承認を求めます。`deny > ask > allow` のため、組織またはユーザーの deny は workspace の allow で上書きできません。

## ハンズオンで使う Kiro IDE の操作導線

開始前に次を確認します。利用できない場合も演習は継続できます。

- コードまたは文章を選択し、macOS の `Cmd+L`、Windows/Linux の `Ctrl+L` で現在のチャットへ追加できる
- 新規チャットへ追加する場合は `Cmd+Shift+L` または `Ctrl+Shift+L` を使える
- チャットタブを右クリックし、**Open in Editor** で Dockable Chat を開ける
- チャットタブを右クリックし、**Export Chat** を選択できる

選択範囲は Ask Kiro の現在または新しいチャットへ追加します。Export Chat の ZIP には会話、セッション情報、サブ実行が含まれるため、共有前に内容をレビューします。

## draw.io 統合の事前判定

演習開始前にファシリテーターが次を確認し、参加者へ Track A または Track B を指定します。

### Track A - 接続済み draw.io MCP / Power

Kiro IDE の UI で確認します。

- Powers パネルに draw.io 用 Power がインストール済みで、詳細画面を開ける
- または MCP Servers パネルで draw.io 用サーバーが `Connected`
- Power 詳細または MCP Servers パネルに、実際に公開されているツール名が表示される
- 読み取りまたはプレビューだけでなく、図の生成、draw.io で開く、または workspace へ保存する手段が少なくとも 1 つある

次の値は環境ごとに異なるため、当日記入します。

| 置換項目 | 当日の値 |
|---|---|
| `[DRAWIO_INTEGRATION]` | 実際の Power 名または MCP server 名 |
| `[DRAWIO_CREATE_TOOL]` | 実際に表示された生成ツール名。該当なしなら `なし` |
| `[DRAWIO_OPEN_TOOL]` | 実際に表示された open/import ツール名。該当なしなら `なし` |
| `[SAVE_MODE]` | workspace へ直接保存 / draw.io で Save As / Mermaid import |

サーバー command、args、ツール名を教材から推測して入力しません。未接続の場合は、組織またはファシリテーターが配布した信頼済み設定だけを使用します。

### Track B - フォールバック

次のいずれかなら Track B を使用します。

- draw.io Power / MCP が未導入、未接続、または承認されていない
- 利用可能ツールが図の生成・保存に対応しない
- 接続確認に 5 分以上かかる
- 権限プロンプトを安全に承認できない

Track B は Kiro に Mermaid または構造化図面仕様を作らせ、draw.io の `Arrange > Insert > Mermaid`、または手作業で再現します。

## Agent Hooks の設定確認

本教材の Hook 設定は次の形式を使用します。

- 保存場所: `.kiro/hooks/*.json`
- schema: `"version": "v1"`
- 保存後トリガー: `PostFileSave`
- action: `command` または `agent`

オンデマンドの確認は `inclusion: manual` の Steering をチャットで選択して実施します。

## 公式資料

- [Steering](https://kiro.dev/docs/steering/)
- [Hooks v1](https://kiro.dev/docs/ide/whats-new-v1/hooks/)
- [MCP](https://kiro.dev/docs/mcp/)
- [Permissions](https://kiro.dev/docs/permissions/)
- [Powers の導入](https://kiro.dev/docs/powers/installation/)
- [draw.io MCP server](https://www.drawio.com/docs/manual/generate/drawio-mcp-server/)
- [draw.io Mermaid](https://www.drawio.com/docs/manual/mermaid/)
